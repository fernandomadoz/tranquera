module.exports = {
	env: {
		mocha: true
	},
	globals: {
		expect: true,
		sinon: true,
		checkAttribute: true
	}
};
