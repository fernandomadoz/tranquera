## [Validate Form Before Submit](#validate-form)

You may want to trigger all inputs validation before submitting a form, maybe display an alert or prevent form submission if any errors are detected. This can be easily acheived using `validateAll` method.