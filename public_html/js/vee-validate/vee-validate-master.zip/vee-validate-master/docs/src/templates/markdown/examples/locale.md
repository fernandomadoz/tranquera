## [Localized Messages](#locale-example)

You may want to display error messages in different languages, `vee-validate` offers a lot of flexibility for multi-language, here is an example on how you may do that

The language below is Arabic (RTL):