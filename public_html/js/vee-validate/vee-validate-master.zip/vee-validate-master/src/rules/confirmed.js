export default (value, other) => String(value) === String(other);
