export default (value, [other] = []) => {
  return value !== other;
};
