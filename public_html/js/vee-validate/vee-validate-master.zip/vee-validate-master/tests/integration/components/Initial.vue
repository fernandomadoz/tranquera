<template>
  <input type="text" name="field" v-validate.initial="'required'">
</template>

<script>
export default {
  name: 'initial-test'
};
</script>
