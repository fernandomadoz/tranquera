<template>
  <input type="text" name="field" v-validate="'required'" data-vv-validate-on="custom">
</template>

<script>
export default {
  name: 'event-test'
};
</script>
