import * as VeeValidate from './vee-validate';

export default VeeValidate;

export * from "./vue";
export * from "./vee-validate";
