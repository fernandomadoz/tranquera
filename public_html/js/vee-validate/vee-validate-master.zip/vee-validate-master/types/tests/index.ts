import * as Vue from 'vue'
import * as VeeValidate from '../vee-validate'
import { Validator, install } from '../vee-validate';

VeeValidate.install(Vue)